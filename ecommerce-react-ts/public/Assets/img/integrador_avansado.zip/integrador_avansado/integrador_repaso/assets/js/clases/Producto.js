class Producto {


    constructor (id,nombre,precio,img){

        this.id = id;
        this.nombre = nombre;
        this.precio= precio;
        this.img= img;
        this.cantidad = 1;

    }




}